import pyttsx3
engine = pyttsx3.init() # object creation

engine.say("Opening 'YoutubeWeb'.")
engine.runAndWait()
engine.stop()
