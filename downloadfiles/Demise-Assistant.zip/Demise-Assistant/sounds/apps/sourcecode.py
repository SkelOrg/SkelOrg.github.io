import pyttsx3
engine = pyttsx3.init() # object creation

engine.say("Opening 'SourceCode'.")
engine.runAndWait()
engine.stop()
